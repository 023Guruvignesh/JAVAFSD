
public class Rangequeries {

	public static void main(String[] args) {
		int array[]= {3,7,2,5,8,9};
		int length = array.length;
		
		Rangequeries.buildSparseTable(array,length);
		
		System.out.println(Rangequeries.query(0,3));
		System.out.println(Rangequeries.query(3,5));
		System.out.println(Rangequeries.query(4,5));
	}
	static int k=16;
	static int N=100000;
	
	static long table[][] = new long[N][k+1];

	static void buildSparseTable(int[] array, int length) {
		// TODO Auto-generated method stub
		for(int i =0;i<length;i++)
			table[i][0]=array[i];
		for(int j=1;j<k;j++)
			for(int i=0;i<length-(1<<j);i++)
				table[i][j]=table[i][j-1]+table[i+(1<<(j-1))][j-1];
	}
	
	static long query(int L, int R) {
		long answer =0;
		for (int j = k; j >= 0; j--) {
			if (L + (1 << j) - 1 <= R) {
				answer = answer + table[L][j];
				L += 1 << j;
			}
		}
		return answer;
	}
}

