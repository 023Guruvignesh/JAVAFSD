package com.springboot.practice;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.springboot.practice.User;
import com.springboot.practice.UserService;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class RestFulWebservicesApplicationTests {
	@Autowired
	private UserService service;
	
	@Test
	public void addTest()
	{
		assertNotNull(service.addUser(new User("amazon","amazon@123","US")));
	}
	@Test
	public void getTest()
	{
		assertEquals(4, service.getAllUser().size());
	}
	
	 @Test
	    public void getByIDTest() {
	             assertEquals("BaljeetS",service.getUserById(3).getName());
	             
	    }
	     
	    
	    @Test
	    public void deleteByIDTest() {
	             assertNotNull(service.deletebyId(3));
	             
	    }
	    
	    @Test
	    public void UpdateByIDTest() {
	             assertNotNull(service.updatebyId(new User("NIKUNJ SONI","NIKUNJ@GMAIL.COM","INDIA"), 9));
	             
	    }
}
