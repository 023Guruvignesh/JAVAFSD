package com.springboot.practice;

import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.practice.Question;

public interface UserRepository extends JpaRepository<Question,Integer> {

}