package com.springboot.practice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;
	
	public List<Question> listAll(){
		return repo.findAll();
	}
	
	public void save(Question user) {
		repo.save(user);
	}
	
	public Question get(int id) {
		return repo.findById(id).get();
	}
	
	public void delete(int id) {
		repo.deleteById(id); 
	}
}