package collection.demo;

import java.util.LinkedList;
import java.util.PriorityQueue;

public class PriorityQueueDemo {

	public static void main(String[] args) {

		PriorityQueue<Integer> pQueue = new PriorityQueue<Integer>();

		pQueue.add(66);
		pQueue.add(67);
		pQueue.add(89);
		pQueue.add(23);

		System.out.println(pQueue);

		System.out.println("Top Element: " + pQueue.peek());

		System.out.println("Printing the top element and removing: " + pQueue.poll());
		System.out.println(pQueue);

		System.out.println("Top Element: " + pQueue.peek());

		pQueue.remove(67);

		System.out.println("After Remove : " + pQueue);

	}

}
