
public class Javamethods {

	// create a method
	public int display(int a, int b) {
		int sum = a + b;
		// return value
		return sum;
	}

	public static void main(String[] args) {

		int num1 = 25;
		int num2 = 25;

		// create an object of Main
		Javamethods obj = new Javamethods();
		// calling method
		int result = obj.display(num1, num2);
		System.out.println("Sum is: " + result);
	}
}
