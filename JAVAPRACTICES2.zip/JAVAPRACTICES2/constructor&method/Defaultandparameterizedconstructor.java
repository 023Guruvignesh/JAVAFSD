class calc {
	int number1;
	int number2;
	int Result;

	// default constructor
	public calc() {
		number1 = 80;
		number2 = 90;
		System.out.println("default constructor");
	}

	// parameterized constructor
	public calc(int n) {
		number1 = 80;
		number2 = 90;
		System.out.println(" constructor");
	}

}

public class Defaultandparameterizedconstructor {
	public static void main(String[] args) {
		calc institute = new calc(3);
		// call paramerized constructor
		calc institute1 = new calc();
		// call paramerized constructor

	}

}
