
public class Methodoverloading {
	public void add(int a, int b) {
		System.out.println(a + b);
	}

	public void add(int a, int b, int c) {
		System.out.println(a + b + c);
	}

	public void add(double a, double b, double c) {
		System.out.println(a + b + c);
	}

	public static void main(String[] args) {
		Methodoverloading obj = new Methodoverloading();
		obj.add(1, 5.5, 1);
		obj.add(1, 4);
		obj.add(2, 4, 6);
	}
}
