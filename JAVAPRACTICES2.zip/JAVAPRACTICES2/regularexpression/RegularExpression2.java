package com.regularexpression.demo;



import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression2 {

public static void main(String[] args) {
		
		String username= "[a-z]+";
		String input ="password";
		
		Pattern password = Pattern.compile(username);
		Matcher confirm = password.matcher(input);
		
		while(confirm.find()) {
			System.out.println(input.substring(confirm.start(),confirm.end()));
		}
	}
}
