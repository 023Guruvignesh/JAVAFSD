
package com.regularexpression.demo;

import java.util.regex.*;

public class RegularExpression1 {

	public static void main(String[] args) {

		String Username = "[a-z]+";
		String input = "password1";

		Pattern pattern = Pattern.compile(Username);
		Matcher confirm = pattern.matcher(input);

		if (confirm.matches()) {
			System.out.println("Password Valid");
		} else {
			System.out.println("Invalid Password");
		}
	}
}
