package Array;
public class Singledimensionalarray {

public static void main(String[]args) {
	int nums[]= {2,3,4,5,5};
	for(int i=0;i<4;i++) {
		System.out.println("enter the numbers:"+ nums[i]);
	}
}
}
