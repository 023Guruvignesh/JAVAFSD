package com.innerclass.demo;

class A
{
	public void show() {
		System.out.println("Hello");
	}
}
	/*class B extends A 
	{
		public void show() {
			System.out.println("GoodBye");
		}

	}*/ 
//Anonymous inner class is same like a method overriding but we can use one time

public class AnonymousInnerclass {
public static void main(String[]args) {
	A obj=new A() {
		public void show() {
			System.out.println("GoodBye");
		}
	};
	obj.show();
	}
}

