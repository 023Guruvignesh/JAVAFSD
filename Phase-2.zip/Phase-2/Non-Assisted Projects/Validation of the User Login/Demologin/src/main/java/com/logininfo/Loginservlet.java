package com.logininfo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Loginservlet extends HttpServlet{
	public String Emailid,password;
public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
{
	res.setContentType("text/html");
	Emailid=req.getParameter("E-mail id");
	password=req.getParameter("password");
	PrintWriter out=res.getWriter();
	if((Emailid.equals("terminate@gmail.com"))&&(password.equals("235@hello"))) {
		out.println("you have successfully login");
	}else {
		out.println("you have unsuccessfully login");
	}
	
}
}
