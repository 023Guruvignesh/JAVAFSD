
public class ExplicitTypeCasting {

	public static void main(String[] args) {
		double a= 30.46;
		
		int b=(int) a; 
		
		System.out.println("Converted Double "+a+" to int "+b);

	}

}
