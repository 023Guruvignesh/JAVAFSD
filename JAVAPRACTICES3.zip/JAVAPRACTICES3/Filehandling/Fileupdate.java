package Filehandling;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Fileupdate {
	public static void main(String[]args) throws IOException {
		//writing a file
				try {
					FileWriter Writer = new FileWriter("myfile.txt");
					Writer.write("Files in Java are seriously good!!");
					Writer.close();
					System.out.println("Successfully written data.");
				} catch (IOException e) {
					System.out.println("An error has occurred.");
					e.printStackTrace();
				}
				//append a file
				Path filepath = Paths.get("myfile.txt");
				if (!Files.exists(filepath)) {
					Files.createFile(filepath);
				}
				Files.write(filepath, "text".getBytes(), StandardOpenOption.APPEND);

	}
}
