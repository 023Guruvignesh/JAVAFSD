package Pillarsofoops;

public class Polymorphism {

	public int sum(int x, int y) {
		return (x + y);
	}

	public int sum(int x, int y, int z) {
		return (x + y + z);
	}

	public double sum(double x, double y) {
		return (x + y);
	}

	public static void main(String args[]) {
		Polymorphism arithmetic = new Polymorphism();
		System.out.println(arithmetic.sum(50, 50));
		System.out.println(arithmetic.sum(10, 20, 30));
		System.out.println(arithmetic.sum(11.5, 22.5));
	}

}
