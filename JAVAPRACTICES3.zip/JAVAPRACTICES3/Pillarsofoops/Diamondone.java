package Pillarsofoops;


	public interface Diamondone {

	    default void show() 
	    { 
	        System.out.println("Default First"); 
	    } 
	}


