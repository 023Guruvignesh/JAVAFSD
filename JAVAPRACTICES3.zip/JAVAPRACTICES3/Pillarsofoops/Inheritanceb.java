package Pillarsofoops;

public class Inheritanceb extends Inheritance {

	public int seatHeight;

	public Inheritanceb(int gear, int speed, int startHeight) {
		super(gear, speed);
		seatHeight = startHeight;
	}

	public void setHeight(int newValue) {
		seatHeight = newValue;
	}

	@Override
	public String toString() {
		return (super.toString() + "\nseat height is " + seatHeight);
	}

	public static void main(String args[]) {
		Inheritanceb mb = new Inheritanceb(3, 100, 25);
		System.out.println(mb.toString());
	}

}
