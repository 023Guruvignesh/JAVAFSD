
package CreationThread;

public class ThreadCreation extends Thread{

	public void run() {
		System.out.println("Thread Start running..");
	}
	
	public static void main(String[] args) {
		ThreadCreation error1 = new ThreadCreation();
		ThreadCreation error2 = new ThreadCreation();
		
				error1.start();
				error2.start();
	}
}
