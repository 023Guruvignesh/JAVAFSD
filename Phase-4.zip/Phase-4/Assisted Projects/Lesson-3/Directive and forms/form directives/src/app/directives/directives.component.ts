import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  products=[{"name":"Julie","email":"julie@gmail.com"},
  {"name":"Nohara","email":"nohara@gmail.com"},
  {"name":"Shinchan","email":"shinchan@gmail.com"},
  {"name":"Aslan","email":"aslan@gmail.com"},
  {"name":"Lucy","email":"lucy@gmail.com"},
  {"name":"Moana","email":"moana@gmail.com"},
  {"name":"Susan","email":"susang@gmail.com"},
  {"name":"Heidi","email":"heidi@gmail.com"},
]

flag=false;

show(){
  this.flag=!this.flag;
}

public day= new Date().getDay();
}
