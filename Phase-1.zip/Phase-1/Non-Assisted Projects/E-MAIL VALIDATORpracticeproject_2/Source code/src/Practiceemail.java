

import java.util.*;

public class Practiceemail {
	//private 
	String[]data= {"cat@gmail.com","mouse@gmail.com",
			"yahoo@gmail.com","google@gmail.com",
			"twitter@gmail.com"};
			                  
	
	public boolean checkemails(String emailuser) {
		for(String useremail:data) {
			if(useremail.equals(emailuser)) {
				return true;
			}
		}
		return false;
	}
		

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		
		System.out.println("enter email address:");
		String emailuser=in.next();
		System.out.println("given email: "+emailuser);
		Practiceemail equaldata=new Practiceemail();
		if(equaldata.checkemails(emailuser)==true) {
			System.out.println("email-id is valid");
		}
		else {
			System.out.println("email-id is invalid");
		}
		}

	}


