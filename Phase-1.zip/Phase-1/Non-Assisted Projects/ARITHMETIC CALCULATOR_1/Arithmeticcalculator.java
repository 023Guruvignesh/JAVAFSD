import java.util.Scanner;

public class Arithmeticcalculator {
	public static void main(String[] args) {
		double number1, number2, Result = 0;
		char operator;
		Scanner var = new Scanner(System.in);
		System.out.print("Enter First numbers: ");
		number1 = var.nextDouble();
		System.out.print("Enter Second numbers: ");
		number2 = var.nextDouble();
		System.out.print("\nEnter an operator (+, -, *, /): ");
		operator = var.next().charAt(0);

		switch (operator) {
		case '+':
			Result = number1 + number2;
			break;
		case '-':
			Result = number1 - number2;
			break;
		case '*':
			Result = number1 * number2;
			break;
		case '/':
			Result = number1 / number2;
			break;
		default:
			System.out.printf("Error! Enter correct operator");

		}
		System.out.print("\nThe Result is given as follows:\n");
		System.out.printf(number1 + " " + operator + " " + number2 + " = " + Result);
	}
}