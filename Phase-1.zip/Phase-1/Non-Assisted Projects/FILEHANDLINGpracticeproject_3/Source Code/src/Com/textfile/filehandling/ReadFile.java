
package Com.textfile.filehandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

//Import the IOException class to handle errors
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class ReadFile {

	public static void main(String[] args) throws IOException {
		// reading a file
		try {
			File Obj1 = new File("myfile.txt");
			Scanner Reader = new Scanner(Obj1);
			while (Reader.hasNextLine()) {
				String data = Reader.nextLine();
				System.out.println(" reading data:" + data);
			}
			Reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error has occurred.");
			e.printStackTrace();
		}
		// writing a file
		try {
			FileWriter Writer = new FileWriter("myfile.txt");
			Writer.write("Files in Java are seriously good!!");
			Writer.close();
			System.out.println("Successfully written data.");
		} catch (IOException e) {
			System.out.println("An error has occurred.");
			e.printStackTrace();
		}
		// append a file
		Path filepath = Paths.get("myfile.txt");
		if (!Files.exists(filepath)) {
			Files.createFile(filepath);
		}
		Files.write(filepath, "text is added".getBytes(), StandardOpenOption.APPEND);
		System.out.println("Data is appended sucessfully");

	}
}