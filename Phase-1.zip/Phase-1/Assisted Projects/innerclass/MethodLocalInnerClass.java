
package com.innerclass.demo;

public class MethodLocalInnerClass {

	String name = "Guru";

	public void show(int age) {

		if (age >= 18) {
			class Inner {
				void display() {
					System.out.print("My name is ");
					System.out.println(name);
					System.out.println("My age is " + age);
				}
			}
			Inner in = new Inner();
			in.display();
		} else {
			System.out.println("Below Age");
		}
	}

	public static void main(String[] args) {
		MethodLocalInnerClass obj = new MethodLocalInnerClass();

		obj.show(20);
	}

}
