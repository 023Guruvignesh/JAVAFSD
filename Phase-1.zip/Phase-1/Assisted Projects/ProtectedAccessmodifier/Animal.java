
public class Animal {
	// protected method
    protected void display() {
        System.out.println("I am an animal");
    }
}

