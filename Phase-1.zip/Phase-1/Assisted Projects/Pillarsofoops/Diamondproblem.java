package Pillarsofoops;


	public class Diamondproblem implements Diamondone,Diamondtwo{

		public void show() {
			Diamondone.super.show();
			Diamondtwo.super.show();
		}
		public static void main(String[] args) {
			Diamondproblem display = new Diamondproblem  ();
			display.show();
		}
	}
	
