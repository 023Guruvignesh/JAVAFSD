package Pillarsofoops;

 public interface Diamondtwo {

    default void show() 
    { 
        System.out.println("Default Second"); 
    } 

}


