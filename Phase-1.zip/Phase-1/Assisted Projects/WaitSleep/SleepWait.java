package WaitSleep;
public class SleepWait {

	private static Object LOCK  = new Object();
	
	public static void main(String[] args) {
	try {
		Thread.sleep(1000);
		System.out.println(Thread.currentThread().getName()+" is come after 1 seconds of sleep");
		
		synchronized(LOCK){
			LOCK.wait(3000);
			System.out.println("Object shown after 5 second");
		}
	}
	catch(Exception e) {
		
		System.out.println("Error: "+e);
	}
	
	}
}

