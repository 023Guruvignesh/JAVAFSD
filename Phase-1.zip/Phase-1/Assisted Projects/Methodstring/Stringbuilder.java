package com.Methodstring;

public class Stringbuilder {  
    public static void main(String[] args){  
        StringBuilder builder=new StringBuilder("hello");  
        builder.append("java");  
        System.out.println(builder); 
        
        builder.replace(0,5, "world");
        System.out.println(builder); 
        
    }  
}  



