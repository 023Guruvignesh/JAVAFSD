package map.demo;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		// hashmap is the implementation of map.
		// it inherits hasmap class
		// it maintains insertion order
		// methods: put,get,remove,getKey

		HashMap<Integer, String> map = new HashMap<Integer, String>();

		map.put(1, "Fruits");
		map.put(2, "Dilip");

		map.put(3, "ALex");

		map.put(4, null); // key is not null but value is null
		map.put(null, "Sony");

		map.put(5, "Fruits");

		System.out.println(map);
		System.out.println("Get element at key 3: " + map.get(3));

		System.out.println("Get element at key 5: " + map.get(5));

		System.out.println("Get element at key 4: " + map.get(4));

		System.out.println("Get element at key null: " + map.get(null));

		System.out.println("Get element at key 6: " + map.get(6));

		// remove element by key

		map.remove(5);

		System.out.println(map);

		for (Map.Entry m : map.entrySet()) {

			System.out.println(m.getKey() + " , " + m.getValue());
		}

	}

}
