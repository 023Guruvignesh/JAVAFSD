package Array;

public class Multidimensionalarray {
	public static void main(String[] args) {
		int a[] = { 11, 12, 13, 14 };
		int b[] = { 12, 22, 32, 42 };
		int c[] = { 13, 23, 33, 43 };
		int d[][] = { { 11, 12, 13, 14 }, { 12, 22, 32, 42 }, { 13, 23, 33, 43 },

		};
		for (int i = 0; i < 3; i++) {// rows
			for (int j = 0; j < 4; j++) {
				System.out.print(" " + d[i][j]);// columns
			}
			System.out.println();
		}
	}
}
