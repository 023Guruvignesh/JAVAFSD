package com.Synchronize;

class Counter {
	int count;

	public synchronized void increment() {
		count++;
	}
}

public class Synchronize {
	public static void main(String[] args) throws Exception {
		Counter obj = new Counter();
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				for (int i = 1; i <= 1000; i++) {
					obj.increment();
				}
			}
		});
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				for (int i = 1; i <= 1000; i++) {
					obj.increment();
				}
			}
		});
		t1.start();
		t2.start();
		t1.join();
		System.out.println("count:" + obj.count);
	}
}
