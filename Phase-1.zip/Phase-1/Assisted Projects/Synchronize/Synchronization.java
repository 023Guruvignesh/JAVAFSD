class Counter{
	int count;

public void increment() {
	count++;
}
}
public class Synchronization {
	public static void main(String[] args) {
Counter c=new Counter();
c.increment();
c.increment();
	
System.out.println("count"+c.count);
}
}