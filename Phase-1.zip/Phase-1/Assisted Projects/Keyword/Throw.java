package Keyword;

public class Throw {



	public static void main(String[] args) {
		int a = 10,b=0,rs;
		
		
		try {
			if(b==0)
				throw (new ArithmeticException("Can't divide by zero."));
			else {
				rs= a/b;
				System.out.println("The result is: "+rs);
			}
	}
		catch(ArithmeticException message) {
			System.out.println("Error:"+message);
		}
		System.out.println("End of the Program");
	}
}

